import { useState, useEffect, useId, useRef } from 'react'
import { Filter, Save, X, RotateCcw, BookmarkPlus, Calendar, ChevronDown, FileText } from 'lucide-react'
import { metaApi } from '../lib/api'
import type { CommitFilter, FilterPreset } from '../types'

interface Props {
  repoId: number
  filter: CommitFilter
  onChange: (f: CommitFilter) => void
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function toISO(display: string, endOfDay = false): string | undefined {
  const clean = display.trim().replace(/\//g, '-')
  if (!/^\d{4}-\d{2}-\d{2}$/.test(clean)) return undefined
  return clean + (endOfDay ? 'T23:59:59Z' : 'T00:00:00Z')
}

function toDisplay(iso: string | undefined): string {
  if (!iso) return ''
  return iso.split('T')[0].replace(/-/g, '/')
}

function isValidDate(s: string): boolean {
  if (!s.trim()) return true
  return /^\d{4}\/\d{2}\/\d{2}$/.test(s.trim())
}

function dateToDisplay(d: Date): string {
  return [
    d.getFullYear(),
    String(d.getMonth() + 1).padStart(2, '0'),
    String(d.getDate()).padStart(2, '0'),
  ].join('/')
}

// ── DateInput — fully controlled with datalist ────────────────────────────────
interface DateInputProps {
  inputId: string
  listId: string
  committed: string
  placeholder: string
  allDates: string[]
  endOfDay?: boolean
  onCommit: (iso: string | undefined) => void
}

function DateInput({ inputId, listId, committed, placeholder, allDates, endOfDay = false, onCommit }: DateInputProps) {
  const [draft, setDraft] = useState(committed)
  const prev = useRef(committed)

  // Sync draft whenever parent pushes a new committed value
  useEffect(() => {
    if (committed !== prev.current) {
      setDraft(committed)
      prev.current = committed
    }
  })

  const flush = (val: string) => {
    const v = val.trim()
    if (!v) { onCommit(undefined); return }
    if (isValidDate(v)) onCommit(toISO(v, endOfDay))
  }

  const invalid = draft.length > 0 && !isValidDate(draft)

  return (
    <div>
      <div style={{ position: 'relative' }}>
        <input
          id={inputId}
          list={listId}
          className="input"
          style={{ fontFamily: 'var(--font-mono)', fontSize: 12, paddingRight: 26, borderColor: invalid ? 'var(--danger)' : undefined }}
          placeholder={placeholder}
          value={draft}
          onChange={e => {
            const v = e.target.value
            setDraft(v)
            if (!v.trim() || isValidDate(v)) flush(v)
          }}
          onBlur={e => flush(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') flush((e.target as HTMLInputElement).value) }}
        />
        <datalist id={listId}>
          {allDates.map(d => <option key={d} value={d} />)}
        </datalist>
        {allDates.length > 0 && (
          <ChevronDown size={11} color="var(--txt-3)"
            style={{ position: 'absolute', right: 7, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} />
        )}
      </div>
      {invalid && <div style={{ fontSize: 9, color: 'var(--danger)', marginTop: 2 }}>Expected yyyy/mm/dd</div>}
    </div>
  )
}

// ── FileInput — custom autocomplete with substring matching ──────────────────
interface FileInputProps {
  value: string
  allFiles: string[]
  onChange: (val: string | undefined) => void
}

function FileInput({ value, allFiles, onChange }: FileInputProps) {
  const [open,    setOpen]    = useState(false)
  const [focused, setFocused] = useState(false)
  const [hiIdx,   setHiIdx]   = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Substring match: query tokens must all appear somewhere in the path
  const matches = value.trim().length === 0
    ? allFiles.slice(0, 30)   // show top 30 when empty
    : allFiles.filter(f => {
        const fl = f.toLowerCase()
        return value.trim().toLowerCase().split(/\s+/).every(tok => fl.includes(tok))
      }).slice(0, 40)

  const showDropdown = focused && open && matches.length > 0

  // Close on outside click
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false)
        setFocused(false)
      }
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  const pick = (f: string) => {
    onChange(f)
    setOpen(false)
    setFocused(false)
    inputRef.current?.blur()
  }

  const handleKey = (e: React.KeyboardEvent) => {
    if (!showDropdown) return
    if (e.key === 'ArrowDown') { e.preventDefault(); setHiIdx(i => Math.min(i + 1, matches.length - 1)) }
    if (e.key === 'ArrowUp')   { e.preventDefault(); setHiIdx(i => Math.max(i - 1, 0)) }
    if (e.key === 'Enter')     { e.preventDefault(); pick(matches[hiIdx]) }
    if (e.key === 'Escape')    { setOpen(false) }
  }

  // Highlight matched characters in a file path
  const highlight = (path: string, query: string) => {
    if (!query.trim()) return <span>{path}</span>
    const tokens = query.trim().toLowerCase().split(/\s+/)
    // Find the filename part for emphasis
    const parts = path.split('/')
    const dir  = parts.slice(0, -1).join('/') + (parts.length > 1 ? '/' : '')
    const file = parts[parts.length - 1]
    return (
      <span>
        <span style={{ color: 'var(--txt-3)', fontSize: 10 }}>{dir}</span>
        <span style={{ color: 'var(--txt)', fontWeight: 600 }}>
          {highlightTokens(file, tokens)}
        </span>
      </span>
    )
  }

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <div style={{ position: 'relative' }}>
        <FileText size={13} color="var(--txt-3)"
          style={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }} />
        <input
          ref={inputRef}
          className="input"
          style={{
            paddingLeft: 28, paddingRight: value ? 28 : 10,
            fontFamily: 'var(--font-mono)', fontSize: 12,
            borderColor: showDropdown ? 'var(--accent)' : undefined,
            boxShadow: showDropdown ? '0 0 0 3px rgba(110,231,255,0.1)' : undefined,
          }}
          placeholder="Search files… (type any part of the path)"
          value={value}
          onFocus={() => { setFocused(true); setOpen(true); setHiIdx(0) }}
          onChange={e => { onChange(e.target.value || undefined); setOpen(true); setHiIdx(0) }}
          onKeyDown={handleKey}
        />
        {value && (
          <button
            onClick={() => { onChange(undefined); setOpen(false); inputRef.current?.focus() }}
            style={{ position: 'absolute', right: 7, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--txt-3)', display: 'flex', padding: 0 }}
          >
            <X size={13} />
          </button>
        )}
      </div>

      {/* Dropdown */}
      {showDropdown && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 4px)', left: 0, right: 0, zIndex: 60,
          background: 'var(--bg-2)', border: '1px solid var(--border-hi)',
          borderRadius: 6, overflow: 'hidden',
          boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
          maxHeight: 220, overflowY: 'auto',
        }}>
          <div style={{ padding: '4px 10px 4px', fontSize: 9, color: 'var(--txt-3)', letterSpacing: '0.06em', textTransform: 'uppercase', borderBottom: '1px solid var(--border)', background: 'var(--bg-1)' }}>
            {matches.length} file{matches.length !== 1 ? 's' : ''} match{matches.length === 1 ? 'es' : ''}{value ? ` "${value}"` : ' — showing top 30'}
          </div>
          {matches.map((f, i) => (
            <button
              key={f}
              onMouseDown={e => { e.preventDefault(); pick(f) }}
              onMouseEnter={() => setHiIdx(i)}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 8,
                padding: '6px 10px', border: 'none', cursor: 'pointer', textAlign: 'left',
                fontFamily: 'var(--font-mono)', fontSize: 11,
                background: i === hiIdx ? 'var(--bg-3)' : 'transparent',
                color: 'var(--txt-2)', transition: 'background 0.08s',
                borderLeft: i === hiIdx ? '2px solid var(--accent)' : '2px solid transparent',
              }}
            >
              <FileText size={11} color={i === hiIdx ? 'var(--accent)' : 'var(--txt-3)'} style={{ flexShrink: 0 }} />
              <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {highlight(f, value)}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Active file badge */}
      {value && !showDropdown && (
        <div style={{ marginTop: 5, display: 'flex', alignItems: 'center', gap: 5, fontSize: 10 }}>
          <span style={{ color: 'var(--accent-3)' }}>✓</span>
          <span className="mono" style={{ color: 'var(--txt-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>{value}</span>
        </div>
      )}
    </div>
  )
}

// Wrap matching chars in a highlight span
function highlightTokens(text: string, tokens: string[]): React.ReactNode {
  if (!tokens.length) return text
  // Build a regex that matches any token
  const escaped = tokens.map(t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
  const re = new RegExp(`(${escaped.join('|')})`, 'gi')
  const parts = text.split(re)
  return (
    <>
      {parts.map((p, i) =>
        re.test(p)
          ? <span key={i} style={{ color: 'var(--accent)', background: 'rgba(110,231,255,0.15)', borderRadius: 2 }}>{p}</span>
          : p
      )}
    </>
  )
}

// ── FilterPanel ───────────────────────────────────────────────────────────────
export function FilterPanel({ repoId, filter, onChange }: Props) {
  const uid = useId().replace(/:/g, '')

  const [authors,      setAuthors]     = useState<string[]>([])
  const [branches,     setBranches]    = useState<string[]>([])
  const [allDates,     setAllDates]    = useState<string[]>([])
  const [allFiles,     setAllFiles]    = useState<string[]>([])
  const [rangeFrom,    setRangeFrom]   = useState('')
  const [rangeTo,      setRangeTo]     = useState('')
  const [presets,      setPresets]     = useState<FilterPreset[]>([])
  const [presetName,   setPresetName]  = useState('')
  const [savingPreset, setSavingPreset] = useState(false)
  const [loading,      setLoading]     = useState(true)

  const fromDisplay = toDisplay(filter.date_from)
  const toDisplay_  = toDisplay(filter.date_to)

  useEffect(() => {
    if (!repoId) return
    setLoading(true)

    metaApi.authors(repoId).then(d => setAuthors(Array.isArray(d) ? d : [])).catch(() => {})
    metaApi.branches(repoId).then(d => setBranches(Array.isArray(d) ? d : [])).catch(() => {})
    metaApi.presets(repoId).then(d => setPresets(Array.isArray(d) ? d : [])).catch(() => {})
    metaApi.distinctDates(repoId).then(d => setAllDates(Array.isArray(d) ? d : [])).catch(() => {})
    metaApi.distinctFiles(repoId).then(d => setAllFiles(Array.isArray(d) ? d : [])).catch(() => {})

    metaApi.dateRange(repoId)
      .then(r => {
        setRangeFrom(r.from)
        setRangeTo(r.to)
        // Always seed the full range — this sets filter.date_from/to
        // which flows into fromDisplay / toDisplay_ and into DateInput
        onChange({
          ...filter,
          date_from: toISO(r.from, false),
          date_to:   toISO(r.to,   true),
        })
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [repoId])

  const set = (patch: Partial<CommitFilter>) => onChange({ ...filter, ...patch })

  const applyQuickRange = (days: number) => {
    if (days === 0) {
      onChange({ ...filter, date_from: toISO(rangeFrom, false), date_to: toISO(rangeTo, true) })
    } else {
      const to   = new Date()
      const from = new Date()
      from.setDate(from.getDate() - days)
      onChange({ ...filter, date_from: toISO(dateToDisplay(from), false), date_to: toISO(dateToDisplay(to), true) })
    }
  }

  const reset = () => onChange({
    date_from: rangeFrom ? toISO(rangeFrom, false) : undefined,
    date_to:   rangeTo   ? toISO(rangeTo,   true)  : undefined,
  })

  // "All" is active when From/To match the repo boundaries exactly
  const isFullRange = !!(
    rangeFrom && rangeTo &&
    fromDisplay === rangeFrom &&
    toDisplay_  === rangeTo
  )

  const hasNonDateFilter = !!(filter.author || filter.branch || filter.file)

  const savePreset = async () => {
    if (!presetName.trim()) return
    try {
      const saved = await metaApi.savePreset(repoId, presetName.trim(), filter)
      setPresets(p => [saved, ...p])
      setPresetName('')
      setSavingPreset(false)
    } catch { /* ignore */ }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* Header */}
      <div style={{ padding: '11px 12px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--txt-3)' }}>
          <Filter size={12} /> Filters
          {hasNonDateFilter && <span className="badge badge-cyan" style={{ fontSize: 9 }}>ON</span>}
        </div>
        <button className="btn btn-ghost" style={{ padding: '3px 8px', fontSize: 11 }} onClick={reset} title="Reset to full date range">
          <RotateCcw size={11} /> Reset
        </button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '10px 12px' }}>

        {/* Author */}
        <Field label="Author">
          <select className="select" style={{ width: '100%' }}
            value={filter.author || ''} onChange={e => set({ author: e.target.value || undefined })}>
            <option value="">All authors</option>
            {authors.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
        </Field>

        {/* Branch */}
        <Field label="Branch">
          <select className="select" style={{ width: '100%' }}
            value={filter.branch || ''} onChange={e => set({ branch: e.target.value || undefined })}>
            <option value="">All branches</option>
            {branches.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
        </Field>

        {/* File path — with autocomplete + usage hint */}
        <Field label={
          <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <span>File path</span>
            {allFiles.length > 0 && (
              <span style={{ fontWeight: 400, color: 'var(--txt-3)', fontSize: 9 }}>
                ({allFiles.length} files — click ⓘ for help)
              </span>
            )}
          </div>
        }>
          <FileInput
            value={filter.file || ''}
            allFiles={allFiles}
            onChange={v => set({ file: v })}
          />
        </Field>

        {/* Date range */}
        <Field label={
          <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <Calendar size={10} />
            <span>Date range</span>
            {allDates.length > 0 && (
              <span style={{ fontWeight: 400, color: 'var(--txt-3)', fontSize: 9 }}>
                ({allDates.length} days with commits)
              </span>
            )}
          </div>
        }>

          {/* All — full width, shows actual date span */}
          <button
            onClick={() => applyQuickRange(0)}
            style={{
              width: '100%', textAlign: 'left', padding: '6px 10px', marginBottom: 6,
              background: isFullRange ? 'rgba(110,231,255,0.1)' : 'var(--bg-3)',
              border: `1px solid ${isFullRange ? 'var(--accent)' : 'var(--border)'}`,
              borderRadius: 4, cursor: 'pointer',
              fontFamily: 'var(--font-mono)', fontSize: 11,
              color: isFullRange ? 'var(--accent)' : 'var(--txt-2)',
              fontWeight: isFullRange ? 700 : 400,
              transition: 'all 0.12s',
              display: 'flex', alignItems: 'center', gap: 8,
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)' }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = isFullRange ? 'var(--accent)' : 'var(--border)'; e.currentTarget.style.color = isFullRange ? 'var(--accent)' : 'var(--txt-2)' }}
          >
            <span style={{ opacity: 0.5, fontSize: 12, flexShrink: 0 }}>⟷</span>
            {loading
              ? <span style={{ color: 'var(--txt-3)', fontFamily: 'var(--font-ui)', fontSize: 10 }}>Loading range…</span>
              : rangeFrom && rangeTo
                ? <span style={{ display: 'flex', alignItems: 'center', gap: 0, flex: 1 }}>
                    <span>{rangeFrom}</span>
                    <span style={{ opacity: 0.4, margin: '0 6px' }}>→</span>
                    <span>{rangeTo}</span>
                    {isFullRange && <span style={{ marginLeft: 'auto', fontSize: 9, opacity: 0.6 }}>✓ all</span>}
                  </span>
                : <span style={{ color: 'var(--txt-3)', fontFamily: 'var(--font-ui)', fontSize: 10 }}>All commits</span>
            }
          </button>

          {/* Relative shortcuts */}
          <div style={{ display: 'flex', gap: 4, marginBottom: 10 }}>
            {[{ label: 'Last 7d', days: 7 }, { label: 'Last 30d', days: 30 }, { label: 'Last 90d', days: 90 }].map(({ label, days }) => (
              <button key={days} onClick={() => applyQuickRange(days)} style={{
                flex: 1, padding: '3px 0', fontSize: 10,
                background: 'var(--bg-3)', border: '1px solid var(--border)',
                borderRadius: 4, cursor: 'pointer', fontFamily: 'var(--font-ui)', color: 'var(--txt-3)', transition: 'all 0.1s',
              }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)' }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--txt-3)' }}
              >{label}</button>
            ))}
          </div>

          {/* From */}
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 9, color: 'var(--txt-3)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>From</div>
            <DateInput
              inputId={`${uid}-from`}
              listId={`${uid}-from-list`}
              committed={fromDisplay}
              placeholder={rangeFrom || 'yyyy/mm/dd'}
              allDates={[...allDates].reverse()}
              endOfDay={false}
              onCommit={iso => set({ date_from: iso })}
            />
          </div>

          {/* To */}
          <div>
            <div style={{ fontSize: 9, color: 'var(--txt-3)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>To</div>
            <DateInput
              inputId={`${uid}-to`}
              listId={`${uid}-to-list`}
              committed={toDisplay_}
              placeholder={rangeTo || 'yyyy/mm/dd'}
              allDates={allDates}
              endOfDay={true}
              onCommit={iso => set({ date_to: iso })}
            />
          </div>
        </Field>

        {/* Limit */}
        <Field label={`Limit: ${filter.limit || 100}`}>
          <input type="range" min={10} max={500} step={10} value={filter.limit || 100}
            onChange={e => set({ limit: Number(e.target.value) })}
            style={{ width: '100%', accentColor: 'var(--accent)' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--txt-3)' }}>
            <span>10</span><span>500</span>
          </div>
        </Field>

        {/* Saved presets */}
        {presets.length > 0 && (
          <div style={{ borderTop: '1px solid var(--border)', paddingTop: 10, marginBottom: 10 }}>
            <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--txt-3)', marginBottom: 6 }}>Saved presets</div>
            {presets.map(p => (
              <button key={p.id} onClick={() => onChange(p.filters as CommitFilter)} style={{
                display: 'flex', alignItems: 'center', gap: 6, width: '100%', padding: '6px 8px',
                marginBottom: 4, borderRadius: 4, border: '1px solid var(--border)',
                background: 'none', cursor: 'pointer', color: 'var(--txt-2)', fontSize: 12, fontFamily: 'var(--font-ui)'
              }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-2)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'none')}
              >
                <BookmarkPlus size={11} color="var(--accent-2)" /> {p.name}
              </button>
            ))}
          </div>
        )}

        {/* Save preset */}
        {hasNonDateFilter && !savingPreset && (
          <button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'center', fontSize: 11 }} onClick={() => setSavingPreset(true)}>
            <Save size={11} /> Save as preset
          </button>
        )}
        {savingPreset && (
          <div style={{ display: 'flex', gap: 5 }}>
            <input className="input" style={{ flex: 1, fontSize: 12 }} placeholder="Preset name…"
              value={presetName} onChange={e => setPresetName(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') savePreset() }} />
            <button className="btn btn-primary" style={{ padding: '6px 10px' }} onClick={savePreset}><Save size={12} /></button>
            <button className="btn btn-ghost" style={{ padding: '6px 9px' }} onClick={() => setSavingPreset(false)}><X size={12} /></button>
          </div>
        )}
      </div>
    </div>
  )
}

function Field({ label, children }: { label: React.ReactNode; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--txt-3)', marginBottom: 6 }}>
        {label}
      </div>
      {children}
    </div>
  )
}
